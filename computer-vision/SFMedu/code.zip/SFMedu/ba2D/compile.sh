
g++ ba2D.cc -o ba2D -O3 -I/usr/local/include -I/usr/include/eigen3 -I../lib/ceres/ceres-solver-1.3.0/include/ -I../lib/ceres/ceres-solver-1.3.0/internal/ -L../lib/ceres/ceres-bin-1.3.0/lib/ -lceres -lpthread -lglog -lgflags -lcholmod -lccolamd -lcamd -lcolamd -lamd -llapack -lblas -lcxsparse -lgomp -lprotobuf
